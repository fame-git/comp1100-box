
public class VendingMachine {

	private State state = new Idle(this);

	public State getState() {

		// START YOUR CODE



		// END YOUR CODE
	}

	public void setState(State state) {
		
		// START YOUR CODE
		

		
		// END YOUR CODE
	}
}
