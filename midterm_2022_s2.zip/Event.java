public enum Event {
	AnyButton, ItemSelected, ItemPaid, ItemDispensed, Timeout, Cancelled;
}
