
The given code realises a `GreenGrocery` using the `IteratorDesignPattern`. The green grocery has an iterator that can iterate all the fruits that are restocked.

Please refer to the test cases in `GroceryTest.java` for more details.

You are expected to complete:
* `restock()`, `hasNext()`, `next()` in `GreenGrocery.java` file
