
public enum Transport {
	AIRPLANE, TRAIN, SHIP
}
