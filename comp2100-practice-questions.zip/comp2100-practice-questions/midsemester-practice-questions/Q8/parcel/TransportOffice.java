
public class TransportOffice {

	private static TransportOffice instance;

	private TransportOffice() {
	}

	public static TransportOffice getInstance() {

		// TODO
		// START YOUR CODE

		// YOU ARE ALLOWED TO CHANGE THIS RETURNED VALUE
		return instance;

		// END YOUR CODE
	}

	public Transport transportBy(Parcel parcel) {

		// TODO
		// START YOUR CODE

		// YOU ARE ALLOWED TO CHANGE THIS RETURNED VALUE
		return null;

		// END YOUR CODE
	}
}
