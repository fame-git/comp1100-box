
public class Recipient {

	public Recipient() {
	}

	public void receive(Parcel parcel) {
		// TODO
		// START YOUR CODE

		
		
		// END YOUR CODE
	}
}
