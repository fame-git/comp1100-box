Implement the minimum number of JUnit test cases for the method `findSomething()` in `BranchComplete.java` that is Branch Complete.

Note that each invocation of the method `findSomething()` counts as a single test case. For example, if you call twice `findSomething()` method in the `BranchCompleteTest.java`, then the number of test cases is considered as 2.
All test cases must pass the JUnit test to get full marks. You must use JUnit4 to write your test cases. Otherwise, you may be subject to a certain amount of mark loss.

Upload the file `BranchCompleteTest.java` to Wattle for marking \[If this was a real exam\].
