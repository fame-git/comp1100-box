import org.junit.Test;

public class BranchCompleteTest {

	@Test
	public void test() {

		// TODO
		// START YOUR CODE
		// HINT: assertEquals(result, BranchComplete.findSomething(a, b, c, d));

		// END YOUR CODE
	}
}
