
public enum Key {
	UP, DOWN, RIGHT, LEFT, D, A, W, S, Z, X, C
}
