public class Calculator {

	public double add(double a, double b) {

		//START YOUR CODE


		//END YOUR CODE
	}

	public double subtract(double a, double b) {

		//START YOUR CODE


		//END YOUR CODE
	}

	public double multiply(double a, double b) {

		//START YOUR CODE


		//END YOUR CODE
	}

	public double divide(double a, double b) {

		//START YOUR CODE


		//END YOUR CODE
	}
}
