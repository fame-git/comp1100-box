package comp1110.exam;

public class P1HelloWorld {
    /**
     * Prints out a single line with the words "Hello World".
     *
     * @param args
     */
    public static void main(String[] args) {
        // FIXME complete this method
        System.out.println("Hello World");
    }
}
