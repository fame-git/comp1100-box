package comp1110.exam;

import java.util.*;

/**
 * This class represents a simplified forum. Each page on the forum has a name, the date it was
 * last modified, an admin person and a set of moderator people. Each page is uniquely identified by
 * its name. People may be both admins and moderators.
 */
public class Q5Forum {
    ArrayList<Page> pages = new ArrayList<Page>();
    class Page{
        String name;
        String admin;
        String date;
        Set<String> moderators;

        public Page(String name, String admin, String date, Set<String> moderators) {
            this.name = name;
            this.admin = admin;
            this.date = date;
            this.moderators = moderators;
        }

        public String getName() {
            return name;
        }

        public String getAdmin() {
            return admin;
        }

        public Set<String> getModerators() {
            return moderators;
        }
        public int hashD(){
            return date.hashCode();
        }
        public Set<String> pName(){
            HashSet<String> pN = new HashSet<>();
            for(var v: moderators){
                if(v.charAt(0)>64&&v.charAt(0)<91){
                    pN.add(v);
                }
            }
            return pN;
        }
        public Set<String> People(){
            HashSet<String> people = new HashSet<>();
            people.add(admin);
            people.addAll(moderators);
            return people;
        }

        public String getDate() {
            return date;
        }
    }
    /**
     * Add a page to the forum. If the page name already exists, do not modify the forum.
     *
     * @param name   the name of the page.
     * @param admin  the name of the administrator for this page.
     * @param date   the date this page was last modified in the format "YYYY-MM-DD"
     * @param moderators  the names of moderators of this page.
     * @return true if the page was added, false if the page was not added (because a page with that
     * name already exists).
     */
    public boolean addPage(String name, String admin, String date, Set<String> moderators) {
        var test = new Page(name, admin, date, moderators);
        for(var v: pages){
            if(v.getName().equals(name)){
                return false;
            }
        }
        pages.add(test);
        return true; // FIXME complete this method
    }

    /**
     * Remove the page with the given name from this forum. If no page with the given name
     * exists, do not modify this forum.
     *
     * @param name the name of the page to be removed.
     * @return true if removal was successful, otherwise false.
     */
    public boolean deletePage(String name) {
        for(var v:pages){
            if(v.getName().equals(name)){
                pages.remove(v);
                return true;
            }
        }
        return false; // FIXME complete this method
    }

    /**
     * @return the total number of pages in this forum.
     */
    public int getPageCount() {
        return pages.size(); // FIXME complete this method
    }

    /**
     * Get the names of all pages that have the given admin. If the given name is not an
     * admin for any files, return an empty set.
     *
     * @param admin the admin to search for.
     * @return a set of all names of pages that have this admin.
     */
    public Set<String> getPagesForAdmin(String admin) {
        HashSet<String> ad = new HashSet<>();
        for(var v: pages){
            if(v.getAdmin().equals(admin)){
                ad.add(v.getName());
            }
        }
        return ad; // FIXME complete this method
    }

    /**
     * Get the names of all pages in which the given person is either an admin or moderator. If
     * the given person is not either of these, return an empty set.
     *
     * @param name the name of a person.
     * @return a set of names of all pages that this person is either an admin or a moderator. If
     * this person is not an admin or moderator for any page, return an empty set.
     */
    public Set<String> getPages(String name) {
        HashSet<String> people = new HashSet<>();
        for(var v: pages){
            if(v.getAdmin().equals(name)){
                people.add(v.getName());
            }
            for(var k: v.getModerators()){
                if(k.equals(name)){
                    people.add(v.getName());
                }
            }
        }
        return people; // FIXME complete this method
    }

    /**
     * Get the total number of unique people across all pages in this forum. Each person is only
     * counted once even if they are both an admin and a moderator or if they are listed for
     * several pages.
     *
     * @return the number of unique people across all pages.
     */
    public int getNumPeople() {
        HashSet<String> uniP = new HashSet<>();
        for(var v: pages){
            uniP.add(v.getAdmin());
            uniP.addAll(v.pName());

        }
        int count =0;
        for(int i = 0; i < uniP.size();i++){
            count++;
        }
        return count; // FIXME complete this method
    }

    /**
     * Get the greatest number of pages that a person is an admin or moderator for. If a given
     * person is both an admin and a moderator for a page, that page only counts once.
     *
     * @return the maximum number of pages for any person
     */
    public int getMaxPages() {
        HashMap<String, Set<String>> pp = new HashMap<>();
        for(var v:pages){
            for(var k: v.People()){
                if(pp.containsKey(k)){
                    Set<String> uP = pp.get(k);
                    uP.add(v.getName());
                    pp.put(k,uP);
                }else{
                    HashSet<String> uP = new HashSet<>();
                    uP.add(v.getName());
                    pp.put(k,uP);
                }
            }
        }
        ArrayList<Integer> num = new ArrayList<>();
        for(var v:pp.values()){
            num.add(v.size());
        }
        return Collections.max(num); // FIXME complete this method
    }

    /**
     * Get the names of all pages in the forum that were modified after the given date.
     *
     * @param date the date in the format "YYYY-MM-DD"
     * @return a set of names of all pages that were modified after the given date. If there are no
     * pages that were modified after the date, return an empty set.
     */
    public Set<String> getPagesAfterDate(String date) {
        HashSet<String> modP = new HashSet<>();
        for(var v: pages){
            if(v.hashD()>date.hashCode()){
                modP.add(v.getName());
            }
        }
        return modP; // FIXME complete this method
    }

    /**
     * Get the maximum number of unique admins and moderators across any single date. If a person
     * is an admin or moderator for multiple pages that were modified on the same date, this only
     * adds one towards the total number of people.
     *
     * @return the maximum number of people for any single date.
     */
    public int getMaxPeople() {
        HashMap<String,Set<String>> uniD = new HashMap<>();
        for(var v: pages){
            for(var k: v.People()){
                if(uniD.containsKey(v.getDate())){
                    Set<String> uniP = uniD.get(v.getDate());
                    uniP.add(k);
                    uniD.put(v.getDate(),uniP);
                }else{
                    HashSet<String> uniP = new HashSet<>();
                    uniP.add(k);
                    uniD.put(v.getDate(),uniP);
                }
            }
        }
        System.out.println(uniD);
        ArrayList<Integer> num = new ArrayList<>();
        for(var j: uniD.values()){
            num.add(j.size());
        }
        return Collections.max(num); // FIXME this method might be useful for the second part of Q5
    }
}
