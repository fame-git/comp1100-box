package comp1110.exam;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * COMP1110 Exam, Question 3.1
 * <p>
 * This class represents a library of books.
 *
 * Each book has:
 *    an ISBN (a unique identifier),
 *    a year of first publication,
 *    a list of authors
 *    a title (also unique)
 *    a rating (0.0 - 5.0)
 *
 */
public class Q3Library {

    ArrayList<Book> books = new ArrayList<>();

    class Book{
        int isbn;
        int year;
        Set<String> authors;
        String title;
        float rating;

        public Book(int isbn, int year, Set<String> authors, String title, float rating) {
            this.isbn = isbn;
            this.year = year;
            this.authors = authors;
            this.title = title;
            this.rating = rating;
        }

        public int getIsbn() {
            return isbn;
        }

        public float getRating() {
            return rating;
        }

        public String getTitle() {
            return title;
        }

        public Set<String> getAuthors() {
            return authors;
        }

        public int getYear() {
            return year;
        }



    }
    /**
     * Add a new book to the library. If there exists a book with this ISBN,
     * do not modify this library.
     *
     * @
     * @param isbn The ISBN of the book (which uniquely identifies it)
     * @param year     the year that the book was first published
     * @param authors the authors of the book
     * @param title the title of the book (also unique)
     * @param rating the average reader rating for this book (0.0 - 5.0)
     * @return true if the book was added to the library, or false if the
     * book was not added (because there is already a book with that isbn)
     */
    public boolean addBook(int isbn, int year, Set<String> authors,  String title, float rating) {
        // FIXME complete this method
        Book base = new Book(isbn, year, authors, title, rating);
        for(var v: books){
            if(v.getIsbn()==isbn){
                return false;
            }
        }
        books.add(base);
        return true;
    }


    /**
     * Remove the book with the given isbn from the library.
     * If no book with the given name exists, do not modify the library.
     *
     * @param isbn The ISBN of the book (which uniquely identifies it)
     * @return true if the removal was successful, otherwise false
     */
    public boolean deleteBook(int isbn) {
        for(var v: books){
            if(v.getIsbn()==isbn){
                books.remove(v);
                return true;
            }
        }
        // FIXME complete this method
        return false;
    }

    /**
     * @return the total number of books in this library
     */
    public int getBookCount() {
        Set<String> book = new HashSet<>();
        for(var v: books){
            book.add(v.getTitle());
        }

            // FIXME complete this method

        return book.size();
    }

    /**
     * Get the titles of all books in the library that have a rating greater
     * than or equal to the rating provided.
     *
     * @param rating Only include books with a rating greater than or equal
     *                to this number.
     * @return the names of all books with a rating greater than or equal to
     * the argument rating
     */
    public Set<String> getTopBooks(float rating) {
        Set<String> top = new HashSet<>();
        for(var v: books){
            if(v.getRating()>=rating){
                top.add(v.getTitle());
            }
        }
        // FIXME complete this method

        return top;
    }

    /**
     * Get the names of all books that were written by a particular person.
     * If the given person has not written any book in the library,
     * return an empty set.
     *
     * @param author the name of a author
     * @return the names of all books for which the given person was an author
     */
    public Set<String> getAuthorBooks(String author) {
        // FIXME complete this method
        Set<String> book = new HashSet<>();
        for(var v: books){
            if(v.getAuthors().contains(author)){
                book.add(v.getTitle());
            }
        }
        return book;
    }

    /**
     * Gets the total number of unique authors across all books in this library.
     * Each author is only counted once, even if they have written multiple
     * books.
     *
     * For example, if there are four books in the library:
     * 439023483, 2008, "The Hunger Games", 4.34, authors: "Suzanne Collins"
     * 439023491, 2009, "Catching Fire", 4.3, authors: "Suzanne Collins"
     * 439023513, 2010, "Mockingjay", 4.03, authors: "Suzanne Collins"
     * 60764899, 1950, "The Lion, the Witch and the Wardrobe", 4.19, authors: "C.S. Lewis"
     * 61234001, 2005, "Freakonomics: A Rogue Economist Explores the Hidden Side of Everything", 3.93, authors: "Steven D. Levitt", "Stephen J. Dubner"
     * then getNumAuthors() == 4.
     *
     * @return the number of unique authors across all books
     */
    public int getNumAuthors() {
        // FIXME complete this method
        Set<String> num = new HashSet<>();
        for(var v: books){
            num.addAll(v.getAuthors());
        }
        return num.size();
    }

    /**
     * Checks whether two people are co-authors (they were authors of the same book).
     *
     * @return true if person1 and person2 are both authors of the same book
     */
    public boolean areCoAuthors(String person1, String person2) {
        // FIXME complete this method
        for(var v: books){
            if(v.getAuthors().contains(person1) && v.getAuthors().contains(person2)){
                return true;
            }
        }
        return false;
    }

    /**
     * @return the first year in which the given author published a book
     * that is in this library, or -1 if they were not an author of any
     * book in this library.
     */
    public int getFirstPublishYear(String personName) {
        // FIXME complete this method
        Set<Integer> year = new HashSet<>();
        for(var v: books){
            if(v.getAuthors().contains(personName)){
                year.add(v.getYear());
            }
        }
        if(year.size()==0) {
            return -1;
        }else{
            return Collections.min(year);
        }
    }

    /**
     * Gets the greatest number of books that any person has been an
     * author of.
     * <p>
     * For example, if there are four books in the library:
     * 439023483, 2008, "The Hunger Games", 4.34, authors: "Suzanne Collins"
     * 439023491, 2009, "Catching Fire", 4.3, authors: "Suzanne Collins"
     * 439023513, 2010, "Mockingjay", 4.03, authors: "Suzanne Collins"
     * 60764899, 1950, "The Lion, the Witch and the Wardrobe", 4.19, authors: "C.S. Lewis"
     * 61234001, 2005, "Freakonomics: A Rogue Economist Explores the Hidden Side of Everything", 3.93, authors: "Steven D. Levitt", "Stephen J. Dubner"
     * then getMaxBooks() == 3.
     *
     * @return the maximum number of books written by any person
     */
    public int getMaxBooks() {
        ArrayList<String> author = new ArrayList<>();

        for(var v: books){
            author.addAll(v.getAuthors());
        }

        ArrayList<Integer> freq = new ArrayList<>();
        for(var j: author){
            freq.add(Collections.frequency(author,j));
        }
        // FIXME complete this method
        return Collections.max(freq);
    }

    /**
     * Gets the maximum number of unique co-authors of any author.
     *
     * Only unique co-authors are counted i.e. if two authors co-author
     * multiple books, this only adds one towards the total number
     * of co-authors.
     * <p>
     * For example, if there are eight books in the library:
     *
     * 743477111, 1595, "An Excellent conceited Tragedie of Romeo and Juliet", 3.73, authors: "William Shakespeare", "Robert Jackson", "Rex Gibson"
     * 521618746, 1600, "The Tragicall Historie of Hamlet, Prince of Denmark"	4, authors: "William Shakespeare", "Richard Andrews", "Rex Gibson"
     * 743477103, 1606, "The Tragedy of Macbeth", 3.88, authors: William Shakespeare
     * 743477545, 1595, "A Midsummer Night's Dream", 3.94, authors: "William Shakespeare", "Barbara A. Mowat", "Paul Werstine", "Catherine Belsey"
     * 679783261, 1813, "Pride and Prejudice", 4.24, authors: "Jane Austen"
     * 141439661, 1811, "Sense and Sensibility, 4.06, authors: "Jane Austen", "Tony Tanner", "Ros Ballaster"
     * 141439580, 1815, "Emma", 3.99, "Jane Austen", "Fiona Stafford"
     * 192802631, 1817, "Persuasion",	4.13, "Jane Austen", "James Kinsley", "Deidre Shauna Lynch"
     *
     * then getMaxCoAuthors would return 6, which is the number of unique
     * co-authors for William Shakespeare in that library.  Notice that
     * "Rex Gibson" co-authors on two books, but is only counted once.
     *
     * @return the maximum number of co-authors for any author
     */
    public int getMaxCoauthors() {
        //Set unique co Author
        Set<String> uniCo = new HashSet<>();
        for(var v: books){
            uniCo.addAll(v.getAuthors());
        }
        //Seperated author from book group
        ArrayList<Set<String>> apB = new ArrayList<>();
        for(var v: books){
            apB.add(v.getAuthors());
        }
        //Store co author per author
        ArrayList<Set<String>> freq = new ArrayList<>();
        for(var v:uniCo){
            Set<String> gCo = new HashSet<>();
            for(var k: apB){
                if(k.contains(v)){
                    for(var j: k){
                        if(!j.equals(v)){
                            gCo.add(j);
                        }
                    }
                }
            }
            freq.add(gCo);
        }
        //Check size
        ArrayList<Integer> maxCo = new ArrayList<>();
        for(var v: freq){
            maxCo.add(v.size());
        }
        // FIXME complete this method
        return Collections.max(maxCo);
    }
}
