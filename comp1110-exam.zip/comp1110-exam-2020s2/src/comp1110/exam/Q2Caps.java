package comp1110.exam;

import java.io.*;
import java.nio.Buffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * COMP1110 Final Exam, Question 2
 *
 * 5 Marks
 */
public class Q2Caps {

  /**
   *
   * Q2 Part I (2 marks)
   *
   * Open the specified input file.  If the caps boolean is false, simply
   * copy all bytes of the input file to the specified output file.  Part II
   * covers the case where the caps boolean is true.
   *
   *
   * Q2 Part II (3 marks)
   *
   * Open the specified input file.  If the caps boolean is true then copy all
   * bytes of the input file directly to the output file, except any word of
   * twenty characters or less that is immediately followed by an exclamation
   * mark ('!').  Such words should be converted to all caps before copied to
   * the output file.  Words longer than 20 charac11ters are copied directly,
   * without capitalizing.
   *
   * A word is defined as a sequence of alphabetical characters ('a' .. 'z' and
   * 'A' .. 'Z') preceded and followed by a non-alphabetical character.
   *
   * Examples (input file contents on left, output on right):
   *  "hi" -> "hi"
   *  "hi!" -> "HI!"
   *  "hi !" -> "hi !"
   *  "Hi there!" -> "Hi THERE!"
   *  "6hi!  Foo" -> "6HI!  Foo"
   *  "6hi4!  Foo" -> "6hi4!  Foo"
   *  "super!" -> "SUPER!"
   *  "supercalifragilisticexpialidocious!" -> "supercalifragilisticexpialidocious!"
   *
   * @param input The name of the input file
   * @param output The name of the output file
   * @param caps if true, capitalize words 20 characters or less if they
   *             are followed by an exclamation mark.
   */
  public static void capitalize(String input, String output, boolean caps) {
    try {
      BufferedReader in = new BufferedReader(new FileReader(input));
      String line;
      List<String> store = new ArrayList<>();
      while((line = in.readLine())!= null){
        if(caps){
          if(line.length()>20){
            for(int i = line.length()-1; i >= 0;i--){
              if(line.charAt(i)=='!'){
                boolean stop = true;
                while(stop){
                  if(line.charAt(i)==' '){
                    stop = false;
                    break;
                  }
                  line = line.substring(0,i-1) + line.substring(i-1,i).toUpperCase() + line.substring(i);
                  i--;
                }
              }
            }
            store.add(line);


          }else{
            if(line.contains("!")){
              int index = line.indexOf("!");
              var dec = line.substring(0,index+1);
              var left = line.substring(index+1);
              var nDec = dec.toUpperCase();
              store.add(nDec+left);
            }else{
              store.add(line);
            }
          }

        }else{
          store.add(line);
        }
      }
      in.close();
      try {
        BufferedWriter out = new BufferedWriter(new FileWriter(output));
        for(var v: store){
          out.write(v);
        }
        out.close();
      } catch (IOException e) {
        e.printStackTrace();
      }
    } catch (IOException e) {
      e.printStackTrace();
    }


    // FIXME complete this method
  }
}
