package comp1110.exam;

/**
 * COMP1110 Final Exam, Question 1.1
 *
 * 5 Marks
 */
public class Q1Remainder {
    /**
     * Given an array of integers and a special value target,
     * return the value in the array that has the smallest
     * remainder when divided by target (ie the value with a
     * remainder closest to zero).  If the array contains two
     * different values with remainders equally close to target,
     * return the smaller value.  If the array is empty, return
     * target.   If target is zero, return zero.
     *
     * @param in    An array of integers
     * @param target a target value to search for in the array
     * @return the value in the array that when divided by target
     * has a remainder closest to zero, returning the smaller of
     * equally close values, and returning target if the array
     * has no entries or the target is zero. i
     */
    public static int findCloseDivisor(int[] in, int target) {
        if(in.length==0){
            return target;
        }
        if(target == 0){
            return target;
        }
        int small = Integer.MAX_VALUE;
        int track = 0;
        for(var v: in){
            var rem = Math.abs(v%target);
            if(small>rem){
                track = v;
                small = rem;
            }
            if(small==rem){
                if(v<track) {
                    track = v;
                    small = rem;
                }
            }
        }

        // FIXME complete this method
        return track;
    }
}
