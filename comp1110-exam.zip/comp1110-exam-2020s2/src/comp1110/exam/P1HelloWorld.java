package comp1110.exam;

/*
 * This is a PRACTICE question.
 *
 * It is NOT worth any marks.
 *
 * You should complete this question and test your answer to check that your
 * setup is configured correctly and the CI is correctly working.
 */
public class P1HelloWorld {
  public static void main(String[] args) {
    // FIXME print out "Hello world!"
    System.out.println("Hello world!");
  }
}
