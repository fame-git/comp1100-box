package comp1110.exam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

/**
 * COMP1110 Final Exam, Question 1.1
 *
 * 5 Marks
 */
public class Q1Ceil {
    /**
     * Given an array of integers and a special value ceil,
     * return the largest value in the array that is less than
     * ceil.
     * If there is no value in the array that is less than
     * ceil, return (ceil+1).
     *
     * @param in    An array of integers
     * @param ceil a target value to search for in the array
     * @return the largest value in the array that is smaller than ceil,
     * or ceil+1 if there is no such value
     */
    public static int findLess(int[] in, int ceil) {
        ArrayList<Integer> max = new ArrayList<>();
        for(var v:in){
            if(v<ceil){
                max.add(v);
            }
        }
        if(max.size()==0){
            return ceil+1;
        }else{
            return Collections.max(max);
        }
         // FIXME complete this method
    }
}
