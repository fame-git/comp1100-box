package comp1110.exam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * COMP1110 Final Exam, Question 1.2 (harder)
 *
 * 5 Marks
 */
public class Q1VowConRecur {
  /**
   * Given a word, if the word is vowcon word, return the number of vowels in
   * the  word, or return -1 if the word is not a vowcon word, and 0 if the word
   * is an empty string.
   *
   * A vowcon word:
   *   a) is composed only of lower case letters, either vowels ('a', 'e', 'i',
   *      'o', 'u') or consonants (all non-vowel lower case letters),
   *   b) has the same first and last letter,
   *   c) after removing the first and last letters, the remaining letters
   *      must also be a vowcon word, or an empty string,
   *   d) if the vowcon word is one character long, that letter must be a vowel.
   *
   * Examples of vowcon words:
   *   a, o, aa, bb, zz, bab, zoz, aaa, aaaaa, zyayz
   *
   * Examples of words that are NOT vowcon words:
   *   b, z, zzz, bbb
   *
   * @param word A word
   * @return the number of vowels in the word if the word is a vowcon word (see
   * above), 0 if it is an empty string, and -1 if it is not a vowcon word.
   */
  public static int vowcon(String word) {
    //Base case
    if(word.length()==0){
      return 0;
    }
    List<Character> vowel = Arrays.asList('a','e','i','o','u');
    //length 1
    if(word.length()==1){
      var mid = word.charAt(0);
      if(vowel.contains(mid)){
        return 1;
      }else{
        return -1;
      }
    }

    if(word.charAt(0)==word.charAt(word.length()-1)){
      var count = vowcon(word.substring(1,word.length()-1));
      if(count == -1){
        return -1;
      }
      if(vowel.contains(word.charAt(0))){
        return 2+count;
      }else{
        return count;
      }
    }
    return -1;  // FIXME complete this method
  }
}
