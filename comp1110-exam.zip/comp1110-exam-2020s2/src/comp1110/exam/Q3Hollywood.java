package comp1110.exam;

import java.util.*;

/**
 * COMP1110 Exam, Question 3.1
 * <p>
 * This class represents a library of films.
 * Each film has a unique name, a year of production, a single director,
 * and one or more actors.
 * Each person (actor or director) is uniquely identified by their name, and a
 * person may be either an actor, or a director, or both, for one or more films.
 */
public class Q3Hollywood {
    ArrayList<Store> keep = new ArrayList<>();
    class Store{
        String filmName;
        int year;
        String director;
        Set<String> actors;

        public Store(String filmName, int year, String director, Set<String> actors) {
            this.filmName = filmName;
            this.year = year;
            this.director = director;
            this.actors = actors;
        }

        public String getFilmName() {
            return filmName;
        }
        public String getDirector(){
            return director;
        }

        public Set<String> getActors() {
            return actors;
        }

        public int getYear() {
            return year;
        }

        public Set<String> people(){
            Set<String> count = new HashSet<>();
            count.addAll(actors);
            count.add(director);
            return count;
        }
    }

    /**
     * Add a new film to this library. If the given film name exists, do not
     * modify this library.
     *
     * @param filmName the name of the film
     * @param year     the year that the film was produced
     * @param director the name of the director of the film
     * @param actors   the names of the actors of the film
     * @return true if the film was added to this library, or false if the
     * film was not added (because a film with the given name already exists)
     */
    public boolean addFilm(String filmName, int year, String director, Set<String> actors) {
        var test = new Store(filmName,year,director,actors);
        for(var v:keep){
            if(v.getFilmName().equals(filmName)){
                return false;
            }
        }
        keep.add(test);
        // FIXME complete this method
        return true;
    }


    /**
     * Remove the film with the given name from the library.
     * If no film with the given name exists, do not modify this library.
     *
     * @param filmName the name of the film to be removed
     * @return true if the removal was successful, otherwise false
     */
    public boolean deleteFilm(String filmName) {
        for(var v:keep){
            if(v.getFilmName().equals(filmName)){
                keep.remove(v);
                return true;
            }
        }
        // FIXME complete this method
        return false;
    }

    /**
     * @return the total number of films in this library
     */
    public int getFilmCount() {
        int count=0;
        for(var v: keep){
            count++;
        }
        // FIXME complete this method
        return count;
    }

    /**
     * Get the names of all films that were directed by a particular person.
     * If the given person has not directed any film, return an empty set.
     *
     * @param directorName the name of a director
     * @return the names of all films for which the given person was director
     */
    public Set<String> getFilmsDirectedBy(String directorName) {
        Set<String> dir = new HashSet<>();
        for(var v: keep){
            if(v.getDirector().equals(directorName)) {
                dir.add(v.getFilmName());
            }
        }
        // FIXME complete this method
        return dir;
    }

    /**
     * Get the names of all films in which the given person has been either
     * an actor or a director.
     * If the given person has not acted or directed in any film, return an
     * empty set.
     *
     * @param personName the name of a person
     * @return the names of all films for which the given person was either
     * an actor or a director
     */
    public Set<String> getFilms(String personName) {
        Set<String> spec = new HashSet<>();
        for(var v: keep){
            //check director
            if((v.getDirector().equals(personName)) || v.getActors().contains(personName)){
                spec.add(v.getFilmName());
            }
        }
        // FIXME complete this method
        return spec;
    }

    /**
     * Gets the total number of unique actors across all films in this library.
     * Each actor is only counted once, even if they have acted in multiple
     * films. Directors are not included in this count unless they have also
     * been actors.
     * For example, if there are four films in the library:
     * "Malcolm X", 1992, director: "Spike Lee", actors: "Denzel Washington", "Angela Bassett", "Spike Lee"
     * "Boyz n da Hood", 1991, director: "John Singleton", actors: "Ice Cube", "Cuba Gooding, Jr.", "Angela Bassett", "Laurence Fishburne"
     * "Higher Learning", 1995, director: "John Singleton", actors: "Jennifer Connolly", "Ice Cube", "Laurence Fishburne"
     * "Waiting to Exhale", 1995, director: "Forest Whitaker", actors: "Whitney Houston", "Angela Bassett"
     * then getNumActors() == 8.
     *
     * @return the number of unique actors across all films
     */
    public int getNumActors() {
        Set<String> actor = new HashSet<>();
        for(var v:keep){
            actor.addAll(v.getActors());
        }
        // FIXME complete this method
        return actor.size();
    }

    /**
     * Checks whether two people are both actors in the same film.
     *
     * @return true if person1 and person2 have both been actors in the same film
     */
    public boolean areCoStars(String person1, String person2) {
        // FIXME complete this method
        for(var v:keep){
            if(v.getActors().contains(person1) && v.getActors().contains(person2)){
                return true;
            }
        }
        return false;
    }

    /**
     * @return the first year in which the given person was either
     * an actor or director in any film, or -1 if they were not an actor
     * or director for any film
     */
    public int getFirstFilmYear(String personName) {
        ArrayList<Integer> year = new ArrayList<>();
        for(var v: keep){
            if(v.getActors().contains(personName) || v.getDirector().equals(personName)){
                year.add(v.getYear());
            }
        }
        // FIXME complete this method
        if(year.size()!=0) {
            return Collections.min(year);
        }else{
            return -1;
        }
    }

    /**
     * Gets the greatest number of films that any person has been either an
     * actor or director in.
     * If a person is both an actor and director in the same film, that film
     * only counts once.
     * <p>
     * For example, if there are four films in the library:
     * "Malcolm X", 1992, director: "Spike Lee", actors: "Denzel Washington", "Angela Bassett", "Spike Lee"
     * "Boyz n da Hood", 1991, director: "John Singleton", actors: "Ice Cube", "Cuba Gooding, Jr.", "Angela Bassett", "Laurence Fishburne"
     * "Higher Learning", 1995, director: "John Singleton", actors: "Jennifer Connolly", "Ice Cube", "Laurence Fishburne"
     * "Waiting to Exhale", 1995, director: "Forest Whitaker", actors: "Whitney Houston", "Angela Bassett"
     * then getMaxFilms() == 3 (for the actor Angela Bassett)
     *
     * @return the maximum number of films for any person
     */
    public int getMaxFilms() {
        ArrayList<String> max = new ArrayList<>();
        for(var v: keep){
            max.addAll(v.people());
        }
        ArrayList<Integer> num = new ArrayList<>();
        for(var j: max){
            num.add(Collections.frequency(max,j));
        }
        // FIXME complete this method
        return Collections.max(num);
    }

    /**
     * Gets the maximum number of unique co-stars of any actor.
     * Two actors are co-stars if they are both actors in the same film.
     * Only unique co-stars are counted i.e. if two actors appear together
     * in multiple films, this only adds one towards the total number
     * of co-stars.
     * <p>
     * For example, if there are three films in the library:
     * "Malcolm X", 1992, director: "Spike Lee", actors: "Denzel Washington", "Angela Bassett", "Spike Lee"
     * "Boyz n da Hood", 1991, director: "John Singleton", actors: "Ice Cube", "Cuba Gooding, Jr.", "Angela Bassett", "Laurence Fishburne"
     * "Higher Learning", 1995, director: "John Singleton", actors: "Jennifer Connolly", "Ice Cube", "Laurence Fishburne"
     * then getMaxCoStars() == 5 for the actor Angela Bassett. Note that
     * although Ice Cube and Laurence Fishburne are co-stars in two films,
     * this only counts once for both and so they only have four co-stars each.
     *
     * @return the maximum number of co-stars for any actor
     */
    public int getMaxCoStars() {
        // FIXME complete this method
        //unique to check co star;
        Set<String> uniqueAct = new HashSet<>();
        for(var v: keep){
            uniqueAct.addAll(v.getActors());
        }
        //store actor for each mov
        ArrayList<Set<String>> act = new ArrayList<>();
        for(var v: keep){
            act.add(v.getActors());
        }
        //number of each actor co star
        ArrayList<Set<String>> co = new ArrayList<>();
        for(var v: uniqueAct){
            Set<String> pCo = new HashSet<>();
            for(var j: act){
                if(j.contains(v)){
                    for(var k: j){
                        if(!k.equals(v)){
                            pCo.add(k);
                        }
                    }

                }
            }
            co.add(pCo);
        }
        //Find the max co star
        ArrayList<Integer> maxCos = new ArrayList<>();
        for(var v: co){
            maxCos.add(v.size());
        }
        return Collections.max(maxCos);
    }
}
