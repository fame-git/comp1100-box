package comp1110.exam;

import java.util.ArrayList;
import java.util.Collections;

/**
 * COMP1110 Final Exam, Question 1.1
 *
 * 5 Marks
 */
public class Q1Floor {
    /**
     * Given an array of integers and a special value floor,
     * return the smallest value in the array that is greater than
     * floor.
     * If there is no value in the array that is greater than
     * floor, return (floor-1).
     *
     * @param in    An array of integers
     * @param floor a target value to search for in the array
     * @return the smallest value in the array that is larger than floor,
     * or floor-1 if there is no such value
     */
    public static int findGreater(int[] in, int floor) {
        ArrayList<Integer> small = new ArrayList<>();
        for(var v: in){
            if(v>floor){
                small.add(v);
            }
        }
        if(small.size()==0){
            return floor-1;
        }else{
            return Collections.min(small);
        }
        // FIXME complete this method
    }
}
