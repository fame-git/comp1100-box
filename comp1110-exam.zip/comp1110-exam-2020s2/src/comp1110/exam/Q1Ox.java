package comp1110.exam;

/**
 * COMP1110 Final Exam, Question 1.2 (harder)
 *
 * 5 Marks
 */
public class Q1Ox {
  /**
   * Given an ox word, return the number of 'x's in the ox word, or return -1
   * if the word is not an ox word, and 0 if the word is an empty string.
   *
   * An ox word: a) is composed only of 'o's and 'x's, b) has more 'x's than
   * 'o's, and c) the leading N-1 letters of an ox word must also be an ox word.
   *
   * For example: x is an ox word, but o is not.  All words that start with o,
   * such as oxxx, are therefore not ox words.  xo is not an ox word because
   * it does not have more x's than o's.  All words that start with xo are
   * therefore not ox words.   Thus xox, xoo, oxx, oxo, oox,
   * and ooo are not ox words.  However, xxx and xxo are both ox words because
   * they have more x's than o's and the left N-1 letters are xx, which is an
   * ox word.
   *
   * @param word A word
   * @return the number of 'x's in the word if the word is an ox word (see
   * above), 0 if it is and empty string, and -1 if it is not an ox word.
   */
  public static int ox(String word) {
    //base case
    if(word.isEmpty() || word.equals("0")){
      return 0;
    }

    if(!word.contains("o") && !word.contains("x")){
      return -1;
    }

    if(word.length()==1){
      if(word.contains("x")){
        return 1;
      }else{
        return -1;
      }
    }

    int x = 0;
    int o = 0;
    if(word.length()>1){

      for(int i = 0; i<word.length(); i++){
        if(word.charAt(i)!='o'&&word.charAt(i)!='x'){
          return -1;
        }
        if(word.charAt(i)=='o'){
          o++;
        }else if(word.charAt(i)=='x'){
          x++;
        }
      }
      if(o>x){
        return -1;
      }else if(x>o){
        if(word.charAt(0)=='x' && word.charAt(1)=='o'){
          return -1;
        }
         String left = word.substring(0,word.length()-1);
         int lX=0;
         int lO=0;
         for(int j = 0;j<left.length(); j++){
           if(word.charAt(j)=='o'){
             lO++;
           }else if(word.charAt(j)=='x'){
             lX++;
           }
          }
         if(lO>lX) {
           return -1;
         }else if(lO==lX){
           return -1;
         }else{
           return x;
         }
      }else{
        return -1;
      }
    }

    return x;  // FIXME complete this method

  }
}
