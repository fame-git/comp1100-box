package comp1110.exam;

import java.util.ArrayList;
import java.util.Collections;

/**
 * COMP1110 Final Exam, Question 1.1
 *
 * 5 Marks
 */
public class Q1Closest {
    /**
     * Given an array of integers and a special value target,
     * return the value in the array that is numerically closest to
     * target. If the array contains two different values equally
     * close to target, return the smaller value.  If the array is
     * empty, return Integer.MAX_VALUE.
     *
     * @param in    An array of integers
     * @param target a target value to search for in the array
     * @return the value in the array that is numerically closest to
     * target, returning the lesser of equally close values, and
     * returning Integer.MAX_VALUE if the array
     * has no entries.
     */
    public static int findClosest(int[] in, int target) {
        //empty case
        if(in.length==0){
            return Integer.MAX_VALUE;
        }
        int small = Integer.MAX_VALUE;
        int track = 0;
        for(var v: in){
            var curr = Math.abs(v-target);
            if(small>curr){
                small=curr;
                track=v;
            }
            if(small==curr){
                if(v<track){
                    track = v;
                    small=curr;
                }
            }
        }
        return track;
    }
}
