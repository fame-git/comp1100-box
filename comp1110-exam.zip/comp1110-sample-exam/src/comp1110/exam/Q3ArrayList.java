package comp1110.exam;

import java.util.Arrays;

/**
 * COMP1110 Final Exam, Question 3
 */
public class Q3ArrayList<T> {
    private static final int INITIAL_SIZE = 2;
    private static final double GROWTH_FACTOR = 1.5;

    T[] values = (T[]) new Object[INITIAL_SIZE];
    int elements = 0;

    /**
     * Add a value to the tail of the list.
     *
     * @param value The value to be added.
     */
    public void add(T value) {
        /* Unimplemented.  Q3 i) [7 Marks] */
        if(elements>= values.length){
            T[] nValues = Arrays.copyOf(values,values.length*2);
            values = nValues;
        }
        values[elements] = value;
        elements++;

    }

    /**
     * Remove the value at the specified index from the list.
     *
     * @param index
     */
    public void remove(int index) {
        /* Unimplemented. Q3 ii) [7 Marks] */
        if(index>=elements || index<0){
            throw new IndexOutOfBoundsException();
        }

        for(int i = index+1; i < elements;i++){
            values[i-1]=values[i];
        }
        values[elements-1] = null;
        elements--;
    }

    /**
     * @param index
     * @return The value at the specified index.
     */
    public T get(int index) {
        if (index >= elements || index < 0)
            throw new IndexOutOfBoundsException();
        return values[index];
    }

    /**
     * @return the current size of the list.
     */
    public int size() {
        return elements;
    }

    /**
     * Reverse the order of the elements of the list.
     */
    public void reverse() {
	    /* Unimplemented. Q3 iii) [6 Marks] */
        for(int i = 0; i < elements/2;i++){
            int j = elements - i - 1;
            var temp = values[i];
            values[i] = values[j];
            values[j] = temp;
        }
    }

    /**
     * @return A string representation of the list.
     */
    public String toString() {
        String rtn = "";
        for (int i = 0; i < elements; i++) {
            rtn += ((i != 0) ? " " : "") + values[i];
        }
        return rtn;
    }
}
