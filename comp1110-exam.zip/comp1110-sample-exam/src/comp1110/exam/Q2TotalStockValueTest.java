package comp1110.exam;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

/**
 * COMP1110 Final Exam, Question 2ii
 */
public class Q2TotalStockValueTest {
    @Rule
    public Timeout globalTimeout = Timeout.millis(500);

    // FIXME add one ore more JUnit unit tests that test the totalStockValue() method of the Q2SimpleStockManager class.

}
