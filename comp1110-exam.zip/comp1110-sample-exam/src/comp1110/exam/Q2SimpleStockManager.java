package comp1110.exam;

import java.util.ArrayList;

/**
 * COMP1110 Final Exam, Question 2i
 */
public class Q2SimpleStockManager {
    ArrayList<Stock> book = new ArrayList<Stock>();
    class Stock{
        String sku;
        String name;
        double price;

        public String getName() {
            return name;
        }

        public String getSku() {
            return sku;
        }

        public double getPrice() {
            return price;
        }

        public void setPrice(double price) {
            this.price = price;
        }

        public Stock(String sku, String name, double price) {
            this.sku = sku;
            this.name = name;
            this.price = price;


        }
    }
    /**
     * A new product has been introduced.
     *
     * @param sku The product’s sku
     * @param name The product’s name
     * @param price The product’s price (per unit)
     */
    public void newItem(String sku, String name, double price) {
        book.add(new Stock(sku, name, price));
        // FIXME Question 2ia: complete this function
    }

    /**
     * Return the name of a product.
     *
     * @param sku The product’s sku
     * @return the name of the product
     */
    public String getItemName(String sku) {
        for(var v:book){
            if(v.getSku().equals(sku)){
                return v.getName();
            }
        }
       return null; // FIXME Question 2ib: complete this function
    }

    /**
     * Return the price of a product.
     *
     * @param sku The product’s sku
     * @return the price of the product
     */
    public double getItemPrice(String sku) {
        for(var v:book){
            if(v.getSku().equals(sku)){
                return v.getPrice();
            }
        }
        return 0; // FIXME Question 2ic: complete this function
    }

    /**
     * Return the amount of stock for a product.
     *
     * @param sku The product’s sku
     * @return the number of items in stock
     */
    public int getStock(String sku) {
        int num = 0;
        for(var v:book){
            if(v.getSku().equals(sku)){
                num++;
            }
        }
        return num-1; // FIXME Question 2id: complete this function
    }

    /**
     * An product has been sold; reduce current stock accordingly.
     *
     * @param sku The product’s sku
     * @param sold The quantity sold
     * @return The number of items of stock remaining after the sale
     */
    public int sale(String sku, int sold) {
        int sub = sold;
        for(var v:book){
            if(v.getSku().equals(sku)){
                for(int i = sub; i>0;i--){
                    book.remove(v);
                }
                break;
            }
        }

        return book.size(); // FIXME Question 2ie: complete this function
    }

    /**
     * New stock has arrived; increase current stock accordingly.
     *
     * @param sku The product’s sku
     * @param added The quantity newly arrived
     */
    public void addStock(String sku, int added) {
        int add = added;
        for(var v:book){
            if(v.getSku().equals(sku)){
                for(int i = 0; i< added;i++){
                    book.add(v);
                }
                break;
            }
        }
        // FIXME Question 2if: complete this function
    }

    /**
     * Set the target amount of stock for a product.
     *
     * @param sku The item’s sku
     * @param target The target quantity desired to be held in stock
     */
    public void setTargetStock(String sku, int target) {
        for(var v : book){
            if(v.getSku().equals(sku)){
                v.setPrice(target);
            }
        }
        // FIXME Question 2ig: complete this function
    }

    /**
     * Stock has been carefully counted. Set current stock correctly.
     *
     * @param sku The product’s sku
     * @param actual The quantity actually in the store
     * @return The stock loss or gain (new current – old current)
     */
    public int setActualStock(String sku, int actual) {
        double diff = 0;
        for(var v:book){
            if(v.getSku().equals(sku)){
                diff =  actual-v.getPrice();
                v.setPrice(actual);
            }
        }


        return (int) diff;  // FIXME Question 2ih: complete this function
    }

    /**
     * Return the number of items required for a given product
     * in order to reach the target stock for that item (target - stock)
     *
     * @param sku The SKU of the item to be queried
     * @return The difference between target and actual stock for that item
     */
    public int getStockRequired(String sku) {
        return -1; // FIXME Question 2ii: complete this function
    }

    /**
     * @return the value of the currently held stock (the price of the
     * product multiplied by the number of items in stock, for all items).
     */
    public double totalStockValue() {
        return 0; // FIXME Question 2ij: complete this function
    }
}
