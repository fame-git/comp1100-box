package comp1110.exam;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * COMP1110 Final Exam, Question 1i
 */
public class Q1Even {
    /**
     * This function takes a positive integer, n,  and returns an array
     * of ints containing all even integers between 1 and n, inclusive of n.
     *
     * for example:
     *    n = 5
     * the result will be
     *        {2, 4}
     */
    public static int[] even(int n) {
        ArrayList<Integer> x = new ArrayList<>();
        for(int i = 1;i<=n;i++){
            if(i%2==0){
                x.add(i);
            }
        }
        int[] y = new int[x.size()];
        for(int i = 0; i < x.size();i++){
            y[i] = x.get(i);
        }
        return y;
        // FIXME Question 1i: complete this function
    }
}
